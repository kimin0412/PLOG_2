package com.ssafy.plog.controller;

public class LoginController {

}
