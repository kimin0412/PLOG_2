package com.ssafy.plog.controller;

public class MainController {

}
