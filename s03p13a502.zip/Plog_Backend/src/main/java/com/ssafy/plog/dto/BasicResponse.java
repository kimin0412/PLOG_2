package com.ssafy.plog.dto;

public class BasicResponse {
    public boolean status;
    public String data;
    public Object object;
    public int temp;
}
