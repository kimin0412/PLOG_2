package com.ssafy.plog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlogBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
