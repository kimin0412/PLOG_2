<template>
  <div>
    settings
  </div>
</template>

<script>
export default {
    name: 'settings'
}
</script>

<style>

</style>