<template>
  <div>
    <div class="d-none d-sm-block">
      프로필 수정 페이지       
    </div>
    <div class="d-block d-sm-none">
      <v-container>
        <v-row>
          <v-col cols="12" class="py-1 text-h5">EDIT</v-col>
          <v-col cols="12" class="py-1 text-h4 font-weight-bold">profile</v-col>
        </v-row>
        <v-row class="mt-10">
          <v-col cols="12" class="py-1 text-h6">Nickname</v-col>
          <v-col cols="12">

          </v-col>
        </v-row>
        <v-row class="mt-3">
          <v-col cols="12" class="py-1 text-h6">Email</v-col>
          <v-col cols="12">

          </v-col>
        </v-row>
        <v-row class="mt-3">
          <v-col cols="12" class="py-1 text-h6">Birthday</v-col>
          <v-col cols="12">

          </v-col>
        </v-row>
      </v-container>
    </div>
  </div>
</template>

<script>

export default {
    name: 'editprofile',
    data() {
        return {
         
        }
    },
    methods: {

    },
    watch: {
    }
}
</script>

<style>

</style>