<template>
  <div>
    <!-- 큰 화면 -->
    <div class="d-none d-sm-block pt-12">
      <div class="centercontent mx-auto">
      <v-container class="pnf">
        <v-row>
          <v-col cols="12" class="py-1 display-1 font-weight-bold text-center">ClientError</v-col>
          <v-col cols="12" class="py-1 display-1 font-weight-light text-center">클라이언트에서 에러가 발생 하였습니다.</v-col>
          <v-col cols="12" class="py-0 text-subtitle-2 text-center grey--text">요청이 올바른지 확인해주시기 바랍니다.</v-col>
          <v-col cols="12" class="pt-4 pb-2 text-subtitle-2 text-center grey--text">이용에 불편을 드려 죄송합니다. </v-col>
        </v-row>
        <v-row class="d-flex justify-center mt-5">
          <router-link v-if="lognow" to="/schedule" class="movebtn"><v-btn rounded color="blue" dark block small><v-icon class="mr-2" small>mdi-calendar</v-icon>Schedule</v-btn></router-link>        
          <router-link v-else to="/aboutus" class="movebtn"><v-btn rounded color="blue" dark block small><v-icon class="mr-2" small>mdi-home</v-icon>HOME</v-btn></router-link>
        </v-row>
      </v-container>
      </div>
    </div>

    <!-- 작은화면 -->
    <div class="d-block d-sm-none">
      <v-container>
        <v-row>
          <v-col cols="12" class="py-1 text-h4 font-weight-bold blue--text">ClientError</v-col>
          <v-col cols="12" class="py-1 text-subtitle-1 font-weight-bold blue--text">클라이언트에서 에러가 발생 하였습니다.</v-col>
        </v-row>
        <v-row class="mt-7">
          <v-col cols="12" class="py-1 text-caption grey--text mt-n3">요청이 올바른지</v-col>
          <v-col cols="12" class="py-1 text-caption grey--text mt-n3">확인해주시기 바랍니다.</v-col>
          <v-col cols="12" class="pb-1 pt-5 text-subtitle-2 font-weight-bold grey--text mt-n3">이용에 불편을 드려 죄송합니다 :)</v-col>
        </v-row>
        <v-row class="mt-5 ml-1">
          <router-link v-if="lognow" to="/schedule" class="movebtn"><v-btn rounded color="blue" dark small><v-icon small class="mr-3">mdi-calendar</v-icon>go home</v-btn></router-link>
          <router-link v-else to="/aboutus" class="movebtn"><v-btn rounded color="blue" dark small><v-icon small class="mr-3">mdi-home</v-icon>go home</v-btn></router-link>

        </v-row>
      </v-container>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ClientError',
  data() {
    return {
    }
  },
  computed: {
    lognow() {
      return this.$store.state.auth.status.loggedIn
    }
  }
}
</script>

<style scoped>
.submitbtn {
  min-width: 100% !important;
}

.linkto {
  text-decoration: none;
  color: rgb(67, 119, 196);
}

.centercontent {
  width: 70%;
}

.movebtn {
    text-decoration: none;
    color: white;
}
.pnf {
  margin-top: 20vh;
}
</style>