export default class User {
    constructor(username, email, password, birthday, phone) {
      this.username = username;
      this.email = email;
      this.password = password;
      this.birthday = birthday;
      this.phone = phone;
    }
  }
  